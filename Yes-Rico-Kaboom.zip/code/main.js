import kaboom from "kaboom";
import { jump, spawnTrees, drawFloor, createPlayer, createLabel, createUltraLabel } from "./xtra_functions"

const FLOOR_HEIGHT = 48;
const JUMP_FORCE = 800;
const SPEED = 480;

kaboom();
loadSprite("duck", "sprites/duck.png");

scene("game", () => {
  // Where we kick off the coding!
  gravity(2000);
  const player = createPlayer("duck", 80, 40);
  loadPedit("ball", "sprites/ball.pedit");
  drawFloor(FLOOR_HEIGHT, 127, 200, 255)
  keyPress("space", () => jump(player, JUMP_FORCE));
  spawnTrees(FLOOR_HEIGHT, 300);
  let score = 0;

  const scoreLabel = createLabel(score, 24, 24)

  action(() => {
    score++;
    scoreLabel.text = score;
  });

  player.collides("tree", () => {
    addKaboom(player.pos);
    go("lose", score);
  });
});
scene("lose", (score) => {
  createUltraLabel(score, width() / 2, height() / 2)
  keyPress("space", () => go("game"));
})

go("game");