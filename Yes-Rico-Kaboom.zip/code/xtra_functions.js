export function jump(player, JUMP_FORCE) {
    if (player.grounded()) {
        player.jump(JUMP_FORCE);
    }
}

export function spawnTrees(FLOOR_HEIGHT, SPEED) {
    add([
        rect(48, rand(32, 96)),
        area(),
        outline(4),
        pos(width(), height() - FLOOR_HEIGHT),
        origin("botleft"),
        color(255, 180, 255),
        move(LEFT, SPEED),
        "tree",
    ]);

    // wait a random amount of time to spawn next tree
    wait(rand(0.5, 1.5), () => spawnTrees(FLOOR_HEIGHT, SPEED));
}

export function drawFloor(FLOOR_HEIGHT, R, G, B) {
  return add([
      rect(width(), FLOOR_HEIGHT),
      outline(4),
      pos(0, height()),
      origin("botleft"),
      area(),
      solid(),
      color(R, G, B),
  ]);
}

export function createPlayer(spriteName, x, y) {
  return add([
        // list of components
        sprite(spriteName),
        pos(x, y),
        area(),
        body(),
        origin("center"),
    ]);
}

export function createLabel(textContent, x, y){
  return add([
        text(textContent),
        pos(x, y),
    ]);
}

export function createUltraLabel(textContent, x, y){
  return add([
        text(textContent),
        pos(x, y),
        scale(2),
        origin("center"),
    ]);
}